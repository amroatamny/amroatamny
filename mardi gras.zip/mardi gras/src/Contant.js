function Myform(){
  let name= document.getElementById("name").value;
  let lastName = document.getElementById("last-name").value;
  let email = document.getElementById("email").value;
  let text = document.getElementById("text-box").value;
    const regex =/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g;
  let text1;
  let text2;
  if(name===""||lastName===""||email===""||text===""){
       text1="please enter every think"
             text2=""
      }
   else if(name!==""&&lastName!==""&&email!==""&&text!==""&&!email.match(regex)){
  text1="";
     text2="You have entered an invalid email address!"}
      else if(name!==""||lastName!==""||email!==""||text!==""||email.match(regex)){
  text1="thanks we will contact with you soon";
     text2=""}

    document.getElementById("fff").innerHTML = text2;


    document.getElementById("ff").innerHTML = text1;
}